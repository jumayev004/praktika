package com.example.projj_1;

public class task1 {

    private double value;

    public task1(double value) {
        this.value = value;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public static double add(double a, double b) {
        return a + b;
    }

    public static double divide(double a, double b) {
        if (b == 0) {
            throw new ArithmeticException("Деление на ноль невозможно.");
        }
        return a / b;
    }

    public static double power(double base, double exponent) {
        return Math.pow(base, exponent);
    }

    public static void main(String[] args) {
        double sum = task1.add(5.0, 3.2);
        double quotient = task1.divide(10.0, 2.0);
        double result = task1.power(2.0, 3.0);

        System.out.println("Сумма: " + sum);
        System.out.println("Частное: " + quotient);
        System.out.println("Возведение в степень: " + result);
        
        task1 wrapper = new task1(7.5);
        System.out.println("Текущее значение: " + wrapper.getValue());

        wrapper.setValue(12.3);
        System.out.println("Обновлённое значение: " + wrapper.getValue());
    }
}
