package com.example.projj_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projj1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
