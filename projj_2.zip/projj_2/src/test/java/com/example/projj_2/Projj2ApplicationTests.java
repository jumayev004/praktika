package com.example.projj_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projj2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
