package com.example.projj_2;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class task2 {
    private static final String URL = "jdbc:mysql://localhost:3306/NameDB";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    public static void main(String[] args) {
        // Коллекции с именами
        List<String> firstList = List.of("Иван", "Мария", "Пётр");
        List<String> secondList = List.of("Анна", "Дмитрий", "Екатерина");

        List<String> mergedList = new ArrayList<>(firstList);
        mergedList.addAll(secondList);

        saveNamesToDatabase(mergedList);

        List<String> namesFromDB = getNamesFromDatabase();
        System.out.println("Имена из базы данных:");
        for (String name : namesFromDB) {
            System.out.println(name);
        }
    }

    private static void saveNamesToDatabase(List<String> names) {
        String insertQuery = "INSERT INTO Names (name) VALUES (?)";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {

            for (String name : names) {
                preparedStatement.setString(1, name);
                preparedStatement.executeUpdate();
            }
            System.out.println("Имена успешно сохранены в базу данных.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static List<String> getNamesFromDatabase() {
        List<String> names = new ArrayList<>();
        String selectQuery = "SELECT name FROM Names";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectQuery)) {

            while (resultSet.next()) {
                names.add(resultSet.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return names;
    }
}
