package com.example.projj_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projj2Application {

    public static void main(String[] args) {
        SpringApplication.run(Projj2Application.class, args);
    }

}
